var searchData=
[
  ['voicebox_469',['VoiceBox',['../classcom_1_1wintermute_1_1bot_1_1vox_1_1_voice_box.html',1,'com::wintermute::bot::vox']]],
  ['voiceboxinterface_470',['VoiceBoxInterface',['../interfacecom_1_1wintermute_1_1bot_1_1vox_1_1_voice_box_interface.html',1,'com::wintermute::bot::vox']]]
];
