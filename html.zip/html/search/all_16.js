var searchData=
[
  ['yellow_399',['Yellow',['../enumcom_1_1wintermute_1_1bot_1_1_bot_view_interface_1_1_bot_status_color.html#a69db1bc2ad0325996b89e67d953ec99c',1,'com::wintermute::bot::BotViewInterface::BotStatusColor']]]
];
