var searchData=
[
  ['knowledgebase_2ejava_504',['KnowledgeBase.java',['../_knowledge_base_8java.html',1,'']]]
];
