var searchData=
[
  ['green_768',['Green',['../enumcom_1_1wintermute_1_1bot_1_1_bot_view_interface_1_1_bot_status_color.html#a02d452722a1ced9a1af2f6c81b7edca7',1,'com::wintermute::bot::BotViewInterface::BotStatusColor']]],
  ['grey_769',['Grey',['../enumcom_1_1wintermute_1_1bot_1_1_bot_view_interface_1_1_bot_status_color.html#a1fc1ec7f07c315d53e8a786c787506b2',1,'com::wintermute::bot::BotViewInterface::BotStatusColor']]]
];
