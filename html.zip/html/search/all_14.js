var searchData=
[
  ['voicebox_388',['VoiceBox',['../classcom_1_1wintermute_1_1bot_1_1vox_1_1_voice_box.html',1,'com::wintermute::bot::vox']]],
  ['voicebox_2ejava_389',['VoiceBox.java',['../_voice_box_8java.html',1,'']]],
  ['voiceboxinterface_390',['VoiceBoxInterface',['../interfacecom_1_1wintermute_1_1bot_1_1vox_1_1_voice_box_interface.html',1,'com::wintermute::bot::vox']]],
  ['voiceboxinterface_2ejava_391',['VoiceBoxInterface.java',['../_voice_box_interface_8java.html',1,'']]]
];
